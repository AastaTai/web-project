<script>
  import { useQuestionState } from "$lib/states/questionState.svelte.js";
  let questionState = useQuestionState();

  const addQuestion = (e) => {
    const question = Object.fromEntries(new FormData(e.target));
    question.id = crypto.randomUUID();
    questionState.add(question);
    e.target.reset();
    e.preventDefault();
  };
</script>

<form onsubmit={addQuestion}>
  <label for="title">Question</label>
  <br />
  <input id="title" name="title" type="text" placeholder="Enter a question title" />
  <br />
  <textarea id="content" name="content" type="text" placeholder="Enter a question content" />
  <br />
  <input type="submit" value="Submit" />
</form>