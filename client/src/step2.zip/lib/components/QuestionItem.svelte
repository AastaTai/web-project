<script>
  import { useQuestionState } from "$lib/states/questionState.svelte.js";
  let questionState = useQuestionState();

  let { question } = $props();
</script>

<label for={question.id}>
  {question.title}
</label>

<button onclick={() => questionState.delete(question.id)}>Delete</button>

<button onclick={() => questionState.upvote(question.id)}>Upvote</button>

<label for={question.id}>
  Upvotes: {question.upvotes}
</label>