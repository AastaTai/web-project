import { Hono } from "@hono/hono";
import { cors } from "@hono/hono/cors";
import { logger } from "@hono/hono/logger";
import postgres from "postgres";

const app = new Hono();
const sql = postgres();

let questions = [];

app.use("/*", cors());
app.use("/*", logger());

app.get("/courses", 
	(c) => c.json({"courses": [ {"id": 1, "name": "Web Software Development" }, {"id": 2, "name": "Device-Agnostic Design" } ] })
);

app.get("/courses/:id", (c) => {
	const id = c.req.param("id");
	return c.json({"course": {"id": parseInt(id), "name": "Course Name" } });
});

app.post("/courses", async (c) => {
	const data = await c.req.json();
	return c.json({"course": {"id": 3, "name": data.name } });
});


app.get("/courses/:id/questions", (c) =>{
	return c.json(questions);
});

app.post("/courses/:id/questions", async (c) => {
	const data = await c.req.json();
	const newQuestion = {
		id: questions.length + 1,
		title: data.title,
		text: data.text,
		upvotes: 0
	};
	questions.push(newQuestion);
	return c.json(newQuestion);
});

app.post("/courses/:id/questions/:qId/upvote", (c) => {
	const qId = parseInt(c.req.param("qId"));
	const question = questions.find(q => q.id === parseInt(qId));
	question.upvotes++;
	return c.json(question);
});

app.delete("/courses/:id/questions/:qId", (c) => {
	const qId = parseInt(c.req.param("qId"));
	const question = questions.find(q => q.id === parseInt(qId));
	questions = questions.filter(q => q.id !== parseInt(qId));
	return c.json(question);
});

export default app;
